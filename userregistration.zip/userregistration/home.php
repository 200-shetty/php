<?php

session_start();



?>


<html>
<head>
    <title> Home Page
    
    </title></head>
    <body>
     
        
        
   
        <h3>Welcome, <?php echo $_SESSION['username']; ?> Login Successful!</h3>
    </body>
    
    <html>